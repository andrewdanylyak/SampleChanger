/*
 * readme.h
 *
 * Created: 18.08.2021 12:00:22
 *  Author: Andrii
 */ 

 fuses:
	Extended:	0xf9
	HIGH:			0xd7
	LOW:			0xe2

lock bits:
	LOCKBIT:	0xfc

AAEC018.280.002-018-A.1.0.1.hex - for FUTABA S3003 motor
AAEC018.280.002-018-A.1.0.2.hex - for SPRINGRC SM-S4303B motor